/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "i2c.h"
#include "rtc.h"
#include "spi.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "AT24CXX.h"
#include "VFD_8MD06INKM.h"
#include "BoardDefines.h"
#include "time.h"
#include "stdio.h"
#include "re_printf.h"
#include "stdlib.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define TIME_STR_LEN    10
#define DATE_STR_LEN    10
#define CMD_STR_LEN     60
#define START_STR_LEN   9

#define TIME_FMT        "%T"
#define DATE_FMT1       "%y/%m/%d"
#define DATE_FMT2       "%m/%d  %u"

#define DATE_CON_TIME   (1000 * 60)
#define CONFIRM_STR     "Hello VFD Clock - Powered By AQin\n"
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

uint8_t UpdateFlag = 0;

char CmdStr[CMD_STR_LEN];
char TimeStr[TIME_STR_LEN];
char DateStr[DATE_STR_LEN];
char StartStr[START_STR_LEN];

uint8_t CurMode = 0;
typedef enum
{
    NormalMode = 0,
    TimeMode,
    DateMode,
    SettingMode
}DevMode;

uint32_t BegSwitchTick = 0;
uint8_t UseDateFmt = 0;

uint8_t ch;
uint8_t CmdLen;
uint8_t NewCmd;

uint8_t VFDOn;
uint8_t VFDOff;
uint8_t LedState;

typedef enum
{
    SET_None,
    SET_Year,
    SET_Month,
    SET_Day,
    SET_Hour,
    SET_Min,
    SET_Sec,
    SET_Submit,
    SET_Null
}CurSetting;
CurSetting CurSetItem;

//������������涨��������ĵ�ǰֵ,��ֵ,��ǰ���Ӣ����,�Ƿ����
//                     ��  ��  ��  ��  ʱ  ��   ��  ��
int16_t SetValMin[8] = {0, 0,  1,  1,  0,  0,  0,  -1};
int16_t SetValList[8];
int16_t SetValMax[8] = {0, 99, 12, 31, 23, 59, 0,   1};
uint8_t SetValChanged[8];
char* SetValName[8] = {
        "None",
        "Year",
        "Mon",
        "Day",
        "Hour",
        "Min",
        "Sec",
        "Submit"
};

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
    /* USER CODE BEGIN 1 */

    /* USER CODE END 1 */

    /* MCU Configuration--------------------------------------------------------*/

    /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
    HAL_Init();

    /* USER CODE BEGIN Init */

    /* USER CODE END Init */

    /* Configure the system clock */
    SystemClock_Config();

    /* USER CODE BEGIN SysInit */

    /* USER CODE END SysInit */

    /* Initialize all configured peripherals */
    MX_GPIO_Init();
    MX_I2C1_Init();
    MX_RTC_Init();
    MX_SPI1_Init();
    MX_TIM2_Init();
    MX_USART1_UART_Init();
    /* USER CODE BEGIN 2 */
    /*�����ʼ��*/
    HAL_UART_Receive_IT(&huart1, &ch, 1);
    HAL_TIM_Base_Start_IT(&htim2);

    RetargetInit(&huart1);
    printf(CONFIRM_STR);

    uint8_t brightness = 255;
    AT24C_ReadByte(AT24_VFD_BRIGHT_CTRL_ADDR, &brightness);
    VFD_InitBrightness(brightness);
    /*������ʼ��*/
    UpdateFlag = 0;
    CurMode = TimeMode;

    HAL_Delay(100);
    if (BTN_Read(BTN1) && !BTN_Read(BTN2))
    {
        LED_Ctrl(LED1, 1);
        CurMode = SettingMode;
    }
    else if (BTN_Read(BTN1) && BTN_Read(BTN2) && BTN_Read(BTN3))
    {
        while (1)
        {
            VFD_ShowScrollString(CONFIRM_STR, 300);
        }
    }



    /*VFD��������*/
    if (CurMode == SettingMode)
    {
        VFD_ShowString(0, "Setting");
        LED_Ctrl(LED_ALL, 1);
    }
    else
    {
        AT24C_ReadArray(AT24_STARTUP_ADDR, (uint8_t*)StartStr, AT24_STARTUP_LEN);
        VFD_ShowStringAnimated(0, StartStr);
        HAL_Delay(1000);
    }


    /*��ȡ����*/
    //LED��ʼ��
    AT24C_ReadByte(AT24_LED_STATE_ADDR, &LedState);
    for (uint8_t i = 0; i < 3; i++)
    {
        LED_Ctrl(3 - i, (LedState >> i) & 1);
    }

    //���ڸ�ʽ���ó�ʼ��
    AT24C_ReadByte(AT24_DATE_FMT_ADDR, &UseDateFmt);

    //VFD�����͹رյ�����
    uint8_t tempList[2] = { 0 };
    AT24C_ReadArray(AT24_VFD_CTRL_ADDR, tempList, AT24_VFD_CTRL_LEN);
    VFDOn = tempList[0];
    VFDOff = tempList[1];

    //�ֶ�����ʱ��
    //RTC_SetDateTime(2023, 1, 1, 4, 0, 0, 0);

    /* USER CODE END 2 */

    /* Infinite loop */
    /* USER CODE BEGIN WHILE */
    while (1)
    {
        //����ˢ��
        if (UpdateFlag && CurMode != SettingMode)
        {
            UpdateFlag = 0;
            struct tm* myTm = RTC_GetDateTime();

            if (CurMode == TimeMode)
            {
                strftime(TimeStr, TIME_STR_LEN, TIME_FMT, myTm);
                VFD_ShowString(0, TimeStr);
            }
            else if (CurMode == DateMode)
            {
                myTm->tm_year -= 2000;
                strftime(DateStr, DATE_STR_LEN, UseDateFmt == 2 ? DATE_FMT2 : DATE_FMT1, myTm);
                VFD_ShowString(0, DateStr);

                if (HAL_GetTick() - BegSwitchTick > DATE_CON_TIME)
                {
                    CurMode = TimeMode;
                }
            }

            if (VFDOn <= myTm->tm_hour && myTm->tm_hour < VFDOff)
            {
                if (!VFD_IsInited())
                {
                    VFD_Init();
                    for (uint8_t i = 0; i < 3; i++)
                    {
                        LED_Ctrl(i + 1, (LedState >> i) & 1);
                    }
                }
            }
            else if (VFDOff != VFDOn)
            {
                if (VFD_IsInited())
                {
                    VFD_DeInit();
                    LED_Ctrl(LED_ALL, 0);
                }
            }
        }

        //�ж��������
        if (NewCmd)
        {
            //1.ʱ�����ã�TIME+1699873617
            if (CmdStr[0] == 'T' &&
                CmdStr[1] == 'I' &&
                CmdStr[2] == 'M' &&
                CmdStr[3] == 'E')
            {
                uint32_t timeStamp = strtoll(CmdStr + 5, 0, 10);

                RTC_SetTimeStamp(timeStamp);
                printf("Time Set Finished\n");
            }
            //2.�����ַ������ã�STR+VFDClock
            else if (CmdStr[0] == 'S' &&
                    CmdStr[1] == 'T' &&
                    CmdStr[2] == 'R')
            {
                uint8_t null[8] = { 0 };
                AT24C_WriteArray(AT24_STARTUP_ADDR, null, AT24_STARTUP_LEN);
                AT24C_WriteArray(AT24_STARTUP_ADDR, (uint8_t*)(CmdStr + 4), strlen(CmdStr + 4));
                printf("Start Up String Set Finished - Reboot Needed\n");
            }
            //3.�ƹ����ã�LED+7
            else if (CmdStr[0] == 'L' &&
                    CmdStr[1] == 'E' &&
                    CmdStr[2] == 'D')
            {
                uint8_t tempLed = strtoll(CmdStr + 4, 0, 10);
                AT24C_WriteByte(AT24_LED_STATE_ADDR, tempLed);
                printf("LED Set Finished - Reboot Needed\n");
            }
            //4.������ʾ��ʽ���ã�DFMT+1
            else if (CmdStr[0] == 'D' &&
                    CmdStr[1] == 'F' &&
                    CmdStr[2] == 'M' &&
                    CmdStr[3] == 'T')
            {
                UseDateFmt = strtol(CmdStr + 5, 0, 10);
                AT24C_WriteByte(AT24_DATE_FMT_ADDR, UseDateFmt);
                printf("Date Fromat Set Finished\n");
            }
            //5.VFDϢ��ʱ�����ã�SSD+0723
            else if (CmdStr[0] == 'S' &&
                    CmdStr[1] == 'S' &&
                    CmdStr[2] == 'D')
            {
                uint16_t tempTime = strtol(CmdStr + 4, 0, 10);
                VFDOn = tempTime / 100;
                VFDOff = tempTime % 100;
                AT24C_WriteByte(AT24_VFD_CTRL_ADDR, VFDOn);
                AT24C_WriteByte(AT24_VFD_CTRL_ADDR + 1, VFDOff);
                printf("VFD On/Off Set Finished\n");
            }
            //6.��������
            else if (CmdStr[0] == 'R' &&
                    CmdStr[1] == 'E' &&
                    CmdStr[2] == 'B' &&
                    CmdStr[3] == 'O' &&
                    CmdStr[4] == 'O' &&
                    CmdStr[5] == 'T')
            {
                printf("Reboot...\n");
                //__disable_irq();
                HAL_NVIC_SystemReset();
            }
            //7.��������
            else if (CmdStr[0] == 'B' &&
                     CmdStr[1] == 'R')
            {
                long tempBr = strtol(CmdStr + 3, 0, 10);
                AT24C_WriteByte(AT24_VFD_BRIGHT_CTRL_ADDR, tempBr);
                printf("Reinitialize VFD, Please wait...\n");
                VFD_DeInit();
                HAL_Delay(100);
                VFD_InitBrightness(tempBr);
                printf("VFD Brightness Set Finished\n");
            }
            //8.ͨ��ȷ�ϣ�CONFIRM
            else if (CmdStr[0] == 'C' &&
                    CmdStr[1] == 'O' &&
                    CmdStr[2] == 'N')
            {
                printf(CONFIRM_STR);
            }

            //���ý��ջ�����
            memset(CmdStr, 0, CMD_STR_LEN);
            CmdLen = 0;
            NewCmd = 0;
        }

        //������ģʽ��ʹ��BTN3�л����ں�ʱ��ģʽ
        if (BTN_Read(BTN3) && CurMode != SettingMode)
        {
            while (BTN_Read(BTN3));

            if (CurMode == TimeMode)
            {
                CurMode = DateMode;
                BegSwitchTick = HAL_GetTick();  //��¼��ʼ�л�Ϊ���ڵ�ʱ�䣬���̶�ʱ��֮���л���ʱ��ģʽ����ֹ����
            }
            else if (CurMode == DateMode)
            {
                CurMode = TimeMode;
            }

            UpdateFlag = 1;
        }

        if (CurMode == SettingMode)
        {
            uint8_t choice;
            CurSetItem = SET_Year;
            HAL_Delay(1000);
            VFD_ClearAll();

            //��ȡ��ǰʱ��
            struct tm* itTm = RTC_GetDateTime();
            SetValList[SET_None]    = 0;
            SetValList[SET_Year]    = (int16_t)(itTm->tm_year - 100);
            SetValList[SET_Month]   = (int16_t)(itTm->tm_mon + 1);
            SetValList[SET_Day]     = (int16_t)itTm->tm_mday;
            SetValList[SET_Hour]    = (int16_t)itTm->tm_hour;
            SetValList[SET_Min]     = (int16_t)itTm->tm_min;
            SetValList[SET_Sec]     = (int16_t)itTm->tm_sec;
            //BTN1: ��һ��������Ŀ BTN2: ��ǰֵ++ BTN3: ��ǰֵ--
            while (1)
            {
                VFD_ClearAll();
                if (CurSetItem == SET_Submit)
                {
                    VFD_ShowString(0, SetValName[CurSetItem]);
                }
                else
                {
                    VFD_ShowString(0, SetValName[CurSetItem]);
                    //VFD_Clear(5, 7);
                    VFD_ShowInt(5, SetValList[CurSetItem]);
                }


                choice = BTN_GetChoice(1);
                switch (choice) {
                    case BTN1:
                        CurSetItem++;
                        if (CurSetItem >= SET_Null)
                            CurSetItem = SET_Year;
                        break;
                    case BTN2:
                        SetValList[CurSetItem]++;
                        if (SetValList[CurSetItem] > SetValMax[CurSetItem])
                            SetValList[CurSetItem] = SetValMin[CurSetItem];
                        SetValChanged[CurSetItem]++;
                        break;
                    case BTN3:
                        SetValList[CurSetItem]--;
                        if (SetValList[CurSetItem] < SetValMin[CurSetItem])
                            SetValList[CurSetItem] = SetValMax[CurSetItem];
                        SetValChanged[CurSetItem]++;
                        break;
                    default:
                        break;
                }

                if (SetValList[SET_Submit] != 0)
                {
//                    RTC_SetDateTime(
//                            SetValList[SET_Year] + 2000,
//                            SetValList[SET_Month],
//                            SetValList[SET_Day],
//                            0,
//                            SetValList[SET_Hour],
//                            SetValList[SET_Min],
//                            SetValList[SET_Sec]);

                    struct tm* tempTm = RTC_GetDateTime();
                    if (SetValChanged[SET_Year])
                        tempTm->tm_year = SetValList[SET_Year] + 100;
                    if (SetValChanged[SET_Month])
                        tempTm->tm_mon = SetValList[SET_Month] - 1;
                    if (SetValChanged[SET_Day])
                        tempTm->tm_mday = SetValList[SET_Day];
                    if (SetValChanged[SET_Hour])
                        tempTm->tm_hour = SetValList[SET_Hour];
                    if (SetValChanged[SET_Min])
                        tempTm->tm_min = SetValList[SET_Min];
                    if (SetValChanged[SET_Sec])
                        tempTm->tm_sec = SetValList[SET_Sec];
                    RTC_SetSTm(tempTm);
                    CurMode = TimeMode;
                    break;
                }
            }
        }
        /* USER CODE END WHILE */

        /* USER CODE BEGIN 3 */
    }
    /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
    RCC_OscInitTypeDef RCC_OscInitStruct = {0};
    RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
    RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

    /** Initializes the RCC Oscillators according to the specified parameters
    * in the RCC_OscInitTypeDef structure.
    */
    RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE|RCC_OSCILLATORTYPE_LSE;
    RCC_OscInitStruct.HSEState = RCC_HSE_ON;
    RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
    RCC_OscInitStruct.LSEState = RCC_LSE_ON;
    RCC_OscInitStruct.HSIState = RCC_HSI_ON;
    RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
    RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
    RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
    if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
    {
        Error_Handler();
    }

    /** Initializes the CPU, AHB and APB buses clocks
    */
    RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                                  |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
    RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
    RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
    RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
    RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

    if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
    {
        Error_Handler();
    }
    PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_RTC;
    PeriphClkInit.RTCClockSelection = RCC_RTCCLKSOURCE_LSE;
    if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
    {
        Error_Handler();
    }
}

/* USER CODE BEGIN 4 */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
    if (htim == &htim2)
    {
        UpdateFlag = 1;

    }
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
    if (huart == &huart1)
    {
        if (ch == '\n')
        {
            NewCmd = 1;
        }
        else
        {
            CmdStr[CmdLen++] = ch;
        }
        HAL_UART_Receive_IT(&huart1, &ch, 1);
    }
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
    /* USER CODE BEGIN Error_Handler_Debug */
    /* User can add his own implementation to report the HAL error return state */
    __disable_irq();
    while (1)
    {
    }
    /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
