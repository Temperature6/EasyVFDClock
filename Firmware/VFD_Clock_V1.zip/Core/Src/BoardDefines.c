//
// Created by AQin on 2023/11/9.
//

#include "BoardDefines.h"
#include "AT24CXX.h"
#include "time.h"
#include "string.h"
struct tm STm;


void LED_Ctrl(LEDs ledNum, uint8_t state)
{
    switch (ledNum)
    {
        case LED1:
            HAL_GPIO_WritePin(LED_PORT, LED1_PIN, (GPIO_PinState)state);
            break;
        case LED2:
            HAL_GPIO_WritePin(LED_PORT, LED2_PIN, (GPIO_PinState)state);
            break;
        case LED3:
            HAL_GPIO_WritePin(LED_PORT, LED3_PIN, (GPIO_PinState)state);
            break;
        case LED_ALL:
            HAL_GPIO_WritePin(LED_PORT, LED1_PIN | LED2_PIN | LED3_PIN, (GPIO_PinState)state);
            break;
        default:
            break;
    }
}

uint8_t BTN_Read(BTNs btnNum)
{
    uint8_t state = 0;
    switch (btnNum)
    {
        case 1:
            state = (HAL_GPIO_ReadPin(BTN_PORT, BTN1_PIN) == GPIO_PIN_SET);
            break;
        case 2:
            state = (HAL_GPIO_ReadPin(BTN_PORT, BTN2_PIN) == GPIO_PIN_SET);
            break;
        case 3:
            state = (HAL_GPIO_ReadPin(BTN_PORT, BTN3_PIN) == GPIO_PIN_SET);
            break;
        default:
            break;
    }
    return state;
}

BTNs BTN_GetChoice(uint8_t block)
{
    BTNs ch = BTN_None;
    while (ch == BTN_None && block)
    {
        if (BTN_Read(BTN1))
        {
            //HAL_Delay(50);
            //if (BTN_Read(BTN1))
            {
                while (BTN_Read(BTN1));
                ch = BTN1;
            }
        }
        if (BTN_Read(BTN2))
        {
            //HAL_Delay(50);
            //if (BTN_Read(BTN2))
            {
                while (BTN_Read(BTN2));
                ch = BTN2;
            }
        }
        if (BTN_Read(BTN3))
        {
            //HAL_Delay(50);
            //if (BTN_Read(BTN3))
            {
                while (BTN_Read(BTN3));
                ch = BTN3;
            }
        }
    }
    return ch;
}

void RTC_SetDateTime(uint16_t year, uint8_t month, uint8_t day, uint8_t weekday, uint8_t hour, uint8_t min, uint8_t sec)
{
    UNUSED(weekday);
    STm.tm_year = year - 1900;
    STm.tm_mon = month - 1;
    STm.tm_mday = day;
    //STm.tm_wday = weekday;
    STm.tm_hour = hour;
    STm.tm_min = min;
    STm.tm_sec = sec;

    RTC_WriteTimeCounter(&hrtc, mktime(&STm));
}

void RTC_SetTimeStamp(uint32_t ts)
{
    ts += TIME_ZONE * 3600;
    RTC_WriteTimeCounter(&hrtc, ts);
}

struct tm *RTC_GetDateTime()
{
    time_t val = RTC_ReadTimeCounter(&hrtc);
    return localtime(&val);
}

void RTC_SetSTm(struct tm* sTm)
{
    RTC_WriteTimeCounter(&hrtc, mktime(sTm));
}
