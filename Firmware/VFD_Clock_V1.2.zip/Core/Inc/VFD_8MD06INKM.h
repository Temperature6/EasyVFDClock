//SP
// Created by AQin on 2023/10/31.
//

#ifndef VFD_8MD06INKM_H
#define VFD_8MD06INKM_H
#include "main.h"

#define VFD_SPI             hspi1   //SCK-PA5 MOSI-PA7
#define VFD_TIMEOUT         0xffff

#define VFD_EN_PORT         GPIOA
#define VFD_EN_PIN          GPIO_PIN_1
#define VFD_CS_PORT         GPIOA
#define VFD_CS_PIN          GPIO_PIN_2
#define VFD_RST_PORT        GPIOA
#define VFD_RST_PIN         GPIO_PIN_3

#define ENABLE_INIT_CHECK   1

#define DEFAULT_BRIGHTNESS  150

extern SPI_HandleTypeDef VFD_SPI;

void VFD_Init();
void VFD_InitBrightness(uint8_t brightness);
uint8_t VFD_IsInited();
void VFD_DeInit();
void VFD_ShowInt(uint8_t pos, int val);
void VFD_ShowChar(uint8_t pos, char ch);
void VFD_ShowString(uint8_t pos, char* str);
void VFD_ShowBitMap(uint8_t pos, uint8_t* data);
void VFD_ShowStringAnimated(int8_t pos, char* str);
void VFD_ShowScrollString(char* str, uint16_t interVal);
void VFD_Clear(uint8_t begPos, uint8_t endPos);
void VFD_ClearAll();

#endif //VFD_8MD06INKM_H
