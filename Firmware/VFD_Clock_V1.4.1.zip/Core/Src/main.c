/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "i2c.h"
#include "rtc.h"
#include "spi.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "AT24CXX.h"
#include "VFD_8MD06INKM.h"
#include "BoardDefines.h"
#include "time.h"
#include "stdio.h"
#include "re_printf.h"
#include "stdlib.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define TIME_STR_LEN        10              //ʱ���ʽ���ַ�������
#define DATE_STR_LEN        10              //���ڸ�ʽ���ַ�������
#define CMD_STR_LEN         60              //�����ַ�����󳤶�
#define START_STR_LEN       9               //�����ַ�������
#define MAX_TIMER_VAL       35999           //����ʱ����ʱʱ�䣨�룩
#define ENABLE_ANIMATION    1               //�Ƿ����������л��Ĺ��ɶ���
#define FRAME_DELAY         30              //���ɶ���ÿ֡�����ms��

#define SHOW_HEART_ON_DATE              //�Ƿ�����ʾ���ڵ�ҳ����ʾһ������

#define TIME_FMT        "%T"            //ʱ���ʽ - 11��45��14
#define DATE_FMT1       "%y/%m/%d"      //���ڸ�ʽ1 - 23/12/10
#define DATE_FMT2       "%m/%d  %u"     //���ڸ�ʽ2 - 12/10  7

#define JUDGE_BITS(x)   ((x) > 999 ? 4 : ((x) > 99 ? 3 : ((x) > 9 ? 2 : (1))))  //��0~9999�������ж�λ��

#define DATE_CON_TIME   (1000 * 60)     //��ʾ���ڵĳ���ʱ�䣨�룩
#define FORCE_ON_TIME   (1000 * 20)     //Ϩ��ģʽ��ǿ��������ʱ�䣨�룩
#define CONFIRM_STR     "Hello VFD Clock - Powered By AQin\n"   //ͨ��ȷ���ַ���
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

uint8_t UpdateFlag = 0;         //����±�־

char CmdStr[CMD_STR_LEN];       //�����ַ���
char OldTimeStr[TIME_STR_LEN];  //ˢ��ǰʱ���ַ���
char NewTimeStr[TIME_STR_LEN];  //ˢ�º�ʱ���ַ���
char DateStr[DATE_STR_LEN];     //�����ַ���
char StartStr[START_STR_LEN];   //�����ַ���

typedef enum
{
    NormalMode = 0,             //����ģʽ��δʹ�ã�
    TimeMode,                   //ʱ����ʾģʽ
    DateMode,                   //������ʾģʽ
    SettingMode,                //�ֶ�����ģʽ
    TimerMode                   //��ʱ��ģʽ
}DevMode;
DevMode CurMode = NormalMode;   //��ǰʱ�ӵ���ʾģʽ

uint32_t BegSwitchTick = 0;     //��ʼ�л�������ģʽ��Tick�����ڳ�ʱ����
uint8_t UseDateFmt = 0;         //ʹ�õ����ڸ�ʽ��ֵΪ1��2

uint8_t ch;                     //�����жϵ��ַ��洢λ��
uint8_t CmdLen;                 //��ǰ�����ж����ݳ���
uint8_t NewCmd;                 //��������ʱ�ı�־λ

uint8_t VFDOnHour;              //VFD��ʼ������ʱ��
uint8_t VFDOffHour;             //VFDϨ����ʱ��
uint8_t LedState;               //LED��״̬��ʹ��һ�����ֵĲ�ͬbitλ����ʾ��ͬLED��״̬

time_t TimerSecs;               //��ʱ�����е�����
uint8_t TimerRunning;           //��ʱ���Ƿ�������
uint8_t TimerOF;                //��ʱ�������־λ

uint8_t ForceVFDOn;             //VFD�Ƿ�Ϊǿ�ƿ���
uint32_t ForceVFDOnBeg;         //VFDǿ�ƿ�����Ticks

typedef enum
{
    SET_None,                   //��ǰδ������Ŀ
    SET_Year,                   //������
    SET_Month,                  //�����·�
    SET_Day,                    //������
    SET_Hour,                   //����ʱ
    SET_Min,                    //���÷���
    SET_Sec,                    //������
    SET_Submit,                 //�ύ����
    SET_Null                    //��������Ŀ��ĩβ
}CurSetting;
CurSetting CurSetItem;          //��ǰ���õ���Ŀ

//������������涨��������ĵ�ǰֵ,��ֵ,��ǰ���Ӣ����,�Ƿ����
//                     ��  ��  ��  ��  ʱ  ��   ��  ��
int16_t SetValMin[8] = {0, 0,  1,  1,  0,  0,  0,  -1};
int16_t SetValList[8];          //�������Ӧ��ֵ
int16_t SetValMax[8] = {0, 99, 12, 31, 23, 59, 0,   1};
uint8_t SetValChanged[8];       //�������Ƿ�ı�
char* SetValName[8] = {         //���������������
        "None",
        "Year",
        "Mon",
        "Day",
        "Hour",
        "Min",
        "Sec",
        "Submit"
};

uint8_t IcoPause[] = { 0x00, 0x1E, 0x00, 0x3C, 0x00 };  //ͼ�꣺��ͣ
uint8_t IcoRun[] = { 0x00, 0x3E, 0x1C, 0x08, 0x00 };    //ͼ�꣺����
#ifdef SHOW_HEART_ON_DATE
uint8_t IcoHeart[] = { 0x0C, 0x1E, 0x3C, 0x1E, 0x0C };  //ͼ�꣺����
#endif //SHOW_HEART_ON_DATE

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
void SoftReset();   //��������
void FmtTime(char* str, uint16_t h, uint8_t min, int8_t sec);   //����ʱ���ʽ��
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
    /* USER CODE BEGIN 1 */

    /* USER CODE END 1 */

    /* MCU Configuration--------------------------------------------------------*/

    /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
    HAL_Init();

    /* USER CODE BEGIN Init */

    /* USER CODE END Init */

    /* Configure the system clock */
    SystemClock_Config();

    /* USER CODE BEGIN SysInit */

    /* USER CODE END SysInit */

    /* Initialize all configured peripherals */
    MX_GPIO_Init();
    MX_I2C1_Init();
    MX_RTC_Init();
    MX_SPI1_Init();
    MX_TIM2_Init();
    MX_USART1_UART_Init();
    /* USER CODE BEGIN 2 */
    /*�����ʼ��*/
    HAL_UART_Receive_IT(&huart1, &ch, 1);
    HAL_TIM_Base_Start_IT(&htim2);

    //����
    RetargetInit(&huart1);
    printf(CONFIRM_STR);

    //��������
    uint8_t brightness = 255;
    AT24C_ReadByte(AT24_VFD_BRIGHT_CTRL_ADDR, &brightness);
    VFD_InitBrightness(brightness);

    /*������ʼ��*/
    UpdateFlag = 0;
    CurMode = TimeMode;

    HAL_Delay(100);
    if (BTN_Read(BTN1) && !BTN_Read(BTN2))
    {
        LED_Ctrl(LED1, 1);
        CurMode = SettingMode;
    }
    //С�ʵ�
    else if (BTN_Read(BTN1) && BTN_Read(BTN2) && BTN_Read(BTN3))
    {
        while (1)
        {
            VFD_ShowScrollString(CONFIRM_STR, 300);
        }
    }


    /*VFD��������*/
    if (CurMode == SettingMode)
    {
        VFD_ShowString(0, "Setting");
        LED_Ctrl(LED_ALL, 1);
    }
    else
    {
        AT24C_ReadArray(AT24_STARTUP_ADDR, (uint8_t*)StartStr, AT24_STARTUP_LEN);
        VFD_ShowStringAnimated(0, StartStr);
        HAL_Delay(1000);
    }

    /*��ȡ����*/
    //LED��ʼ��
    AT24C_ReadByte(AT24_LED_STATE_ADDR, &LedState);
    LED_GroupCtrl(LedState);

    //���ڸ�ʽ���ó�ʼ��
    AT24C_ReadByte(AT24_DATE_FMT_ADDR, &UseDateFmt);

    //VFD�����͹رյ�����
    uint8_t tempList[2] = { 0 };
    AT24C_ReadArray(AT24_VFD_CTRL_ADDR, tempList, AT24_VFD_CTRL_LEN);
    VFDOnHour = tempList[0];
    VFDOffHour = tempList[1];

    //�ֶ�����ʱ��
    //RTC_SetDateTime(2023, 1, 1, 4, 0, 0, 0);
    uint8_t animBuffer[5] = "";
    /* USER CODE END 2 */

    /* Infinite loop */
    /* USER CODE BEGIN WHILE */
    while (1)
    {
        //����ˢ��
        if (UpdateFlag && CurMode != SettingMode)
        {
            UpdateFlag = 0;
            struct tm* myTm = RTC_GetDateTime();
            //ʱ����ʾģʽ��������ʾʱ��
            if (CurMode == TimeMode && VFD_IsInited())
            {

                strftime(NewTimeStr, TIME_STR_LEN, TIME_FMT, myTm);
#if ENABLE_ANIMATION
                for (uint8_t i = 1; i < 9; i++)
                {
                    for (uint8_t j = 0; j < 8; j++)
                    {
                        if (!IS_DIGIT_CHAR(NewTimeStr[j]))
                        {
                            VFD_ShowChar(j, NewTimeStr[j]);
                        }
                        else if (NewTimeStr[j] == OldTimeStr[j])
                        {
                            VFD_ShowBitMap(j, NumberFont[NewTimeStr[j] - '0']);
                        }
                        else if (!IS_DIGIT_CHAR(OldTimeStr[j]))
                        {
                            VFD_GenerateAnimBuffer(i, NumberFont[10], NumberFont[NewTimeStr[j] - '0'], animBuffer);
                            VFD_ShowBitMap(j, animBuffer);
                        }
                        else
                        {
                            VFD_GenerateAnimBuffer(i, NumberFont[OldTimeStr[j] - '0'], NumberFont[NewTimeStr[j] - '0'], animBuffer);
                            VFD_ShowBitMap(j, animBuffer);
                        }
                    }

                    HAL_Delay(FRAME_DELAY);
                }
                memcpy(OldTimeStr, NewTimeStr, TIME_STR_LEN);
#else
                VFD_ShowString(0, NewTimeStr);
#endif //ENABLE_ANIMATION == 1
            }
            //������ʾģʽ����ʾ����
            else if (CurMode == DateMode)
            {
                myTm->tm_year -= 2000;
                strftime(DateStr, DATE_STR_LEN, UseDateFmt == 2 ? DATE_FMT2 : DATE_FMT1, myTm);
                VFD_ShowString(0, DateStr);

                if (HAL_GetTick() - BegSwitchTick > DATE_CON_TIME)
                {
                    CurMode = TimeMode;
                }
#ifdef SHOW_HEART_ON_DATE
                //VFD_ShowBitMap(5, IcoHeart);
                //����ʹ�����ڸ�ʽ2ʱ��ʾС����
                if (UseDateFmt == 2)
                {
                    VFD_ShowBitMap(6, IcoHeart);
                }

#endif //SHOW_HEART_ON_DATE
            }
            //�Ƿ�����Ҫ�ر���Ļ��ʱ��
            if ((VFDOnHour <= myTm->tm_hour && myTm->tm_hour < VFDOffHour) || ForceVFDOn)   //����
            {
                if (!VFD_IsInited())
                {
                    VFD_InitBrightness(brightness);
                    LED_GroupCtrl(LedState);
                }

                if (ForceVFDOn && HAL_GetTick() - ForceVFDOnBeg > FORCE_ON_TIME)
                {
                    ForceVFDOn = 0;
                }
            }
            else if (VFDOffHour != VFDOnHour)                               //Ϩ��
            {
                if (VFD_IsInited())
                {
                    VFD_DeInit();
                    LED_Ctrl(LED_ALL, 0);
                }
            }
        }

        //�ж��������
        if (NewCmd)
        {
            //1.ʱ�����ã�TIME+1699873617
            if (CmdStr[0] == 'T' &&
                CmdStr[1] == 'I' &&
                CmdStr[2] == 'M' &&
                CmdStr[3] == 'E')
            {
                uint32_t timeStamp = strtoll(CmdStr + 5, 0, 10);

                RTC_SetTimeStamp(timeStamp);
                printf("Time Set Finished\n");
            }
            //2.�����ַ������ã�STR+VFDClock
            else if (CmdStr[0] == 'S' &&
                    CmdStr[1] == 'T' &&
                    CmdStr[2] == 'R')
            {
                uint8_t null[8] = { 0 };
                AT24C_WriteArray(AT24_STARTUP_ADDR, null, AT24_STARTUP_LEN);
                AT24C_WriteArray(AT24_STARTUP_ADDR, (uint8_t*)(CmdStr + 4), strlen(CmdStr + 4));
                printf("Start Up String Set Finished - Reboot Needed\n");
            }
            //3.�ƹ����ã�LED+7
            else if (CmdStr[0] == 'L' &&
                    CmdStr[1] == 'E' &&
                    CmdStr[2] == 'D')
            {
                uint8_t tempLed = strtoll(CmdStr + 4, 0, 10);
                AT24C_WriteByte(AT24_LED_STATE_ADDR, tempLed);
                printf("LED Set Finished - Reboot Needed\n");
            }
            //4.������ʾ��ʽ���ã�DFMT+1
            else if (CmdStr[0] == 'D' &&
                    CmdStr[1] == 'F' &&
                    CmdStr[2] == 'M' &&
                    CmdStr[3] == 'T')
            {
                UseDateFmt = strtol(CmdStr + 5, 0, 10);
                AT24C_WriteByte(AT24_DATE_FMT_ADDR, UseDateFmt);
                printf("Date Fromat Set Finished\n");
            }
            //5.VFDϢ��ʱ�����ã�SSD+0723
            else if (CmdStr[0] == 'S' &&
                    CmdStr[1] == 'S' &&
                    CmdStr[2] == 'D')
            {
                uint16_t tempTime = strtol(CmdStr + 4, 0, 10);
                VFDOnHour = tempTime / 100;
                VFDOffHour = tempTime % 100;
                AT24C_WriteByte(AT24_VFD_CTRL_ADDR, VFDOnHour);
                AT24C_WriteByte(AT24_VFD_CTRL_ADDR + 1, VFDOffHour);
                printf("VFD On/Off Set Finished\n");
            }
            //6.��������
            else if (CmdStr[0] == 'R' &&
                    CmdStr[1] == 'E' &&
                    CmdStr[2] == 'B' &&
                    CmdStr[3] == 'O' &&
                    CmdStr[4] == 'O' &&
                    CmdStr[5] == 'T')
            {
                printf("Reboot...\n");
                //__disable_irq();
                //HAL_NVIC_SystemReset();
                SoftReset();
            }
            //7.��������
            else if (CmdStr[0] == 'B' &&
                     CmdStr[1] == 'R')
            {
                long tempBr = strtol(CmdStr + 3, 0, 10);
                AT24C_WriteByte(AT24_VFD_BRIGHT_CTRL_ADDR, tempBr);
                printf("Reinitialize VFD, Please wait...\n");
                VFD_DeInit();
                HAL_Delay(100);
                VFD_InitBrightness(tempBr);
                printf("VFD Brightness Set Finished\n");
            }
            //8.ͨ��ȷ�ϣ�CONFIRM
            else if (CmdStr[0] == 'C' &&
                    CmdStr[1] == 'O' &&
                    CmdStr[2] == 'N')
            {
                printf(CONFIRM_STR);
            }

            //���ý��ջ�����
            memset(CmdStr, 0, CMD_STR_LEN);
            CmdLen = 0;
            NewCmd = 0;
        }

        //������ģʽ�£���Ϩ��ģʽ��ʹ��BTN3�л����ں�ʱ��ģʽ
        if (VFD_IsInited() && BTN_Read(BTN3) && CurMode != SettingMode)
        {
            while (BTN_Read(BTN3));

            if (CurMode == TimeMode)
            {
                CurMode = DateMode;
                BegSwitchTick = HAL_GetTick();  //��¼��ʼ�л�Ϊ���ڵ�ʱ�䣬���̶�ʱ��֮���л���ʱ��ģʽ����ֹ����
            }
            else if (CurMode == DateMode)
            {
                CurMode = TimeMode;
            }

            UpdateFlag = 1;
        }

        //����ģʽ
        if (CurMode == SettingMode)
        {
            uint8_t choice;
            CurSetItem = SET_Year;
            HAL_Delay(1000);
            VFD_ClearAll();

            //��ȡ��ǰʱ��
            struct tm* itTm = RTC_GetDateTime();
            SetValList[SET_None]    = 0;
            SetValList[SET_Year]    = (int16_t)(itTm->tm_year - 100);
            SetValList[SET_Month]   = (int16_t)(itTm->tm_mon + 1);
            SetValList[SET_Day]     = (int16_t)itTm->tm_mday;
            SetValList[SET_Hour]    = (int16_t)itTm->tm_hour;
            SetValList[SET_Min]     = (int16_t)itTm->tm_min;
            SetValList[SET_Sec]     = (int16_t)itTm->tm_sec;
            //BTN1: ��һ��������Ŀ BTN2: ��ǰֵ++ BTN3: ��ǰֵ--
            while (1)
            {
                VFD_ClearAll();
                if (CurSetItem == SET_Submit)
                {
                    VFD_ShowString(0, SetValName[CurSetItem]);
                }
                else
                {
                    VFD_ShowString(0, SetValName[CurSetItem]);
                    //VFD_Clear(5, 7);
                    VFD_ShowInt(5, SetValList[CurSetItem]);
                }


                choice = BTN_GetChoice(1);
                switch (choice) {
                    case BTN1:
                        CurSetItem++;
                        if (CurSetItem >= SET_Null)
                            CurSetItem = SET_Year;
                        break;
                    case BTN2:
                        SetValList[CurSetItem]++;
                        if (SetValList[CurSetItem] > SetValMax[CurSetItem])
                            SetValList[CurSetItem] = SetValMin[CurSetItem];
                        SetValChanged[CurSetItem]++;
                        break;
                    case BTN3:
                        SetValList[CurSetItem]--;
                        if (SetValList[CurSetItem] < SetValMin[CurSetItem])
                            SetValList[CurSetItem] = SetValMax[CurSetItem];
                        SetValChanged[CurSetItem]++;
                        break;
                    default:
                        break;
                }

                if (SetValList[SET_Submit] != 0)
                {
//                    RTC_SetDateTime(
//                            SetValList[SET_Year] + 2000,
//                            SetValList[SET_Month],
//                            SetValList[SET_Day],
//                            0,
//                            SetValList[SET_Hour],
//                            SetValList[SET_Min],
//                            SetValList[SET_Sec]);

                    struct tm* tempTm = RTC_GetDateTime();
                    if (SetValChanged[SET_Year])
                        tempTm->tm_year = SetValList[SET_Year] + 100;
                    if (SetValChanged[SET_Month])
                        tempTm->tm_mon = SetValList[SET_Month] - 1;
                    if (SetValChanged[SET_Day])
                        tempTm->tm_mday = SetValList[SET_Day];
                    if (SetValChanged[SET_Hour])
                        tempTm->tm_hour = SetValList[SET_Hour];
                    if (SetValChanged[SET_Min])
                        tempTm->tm_min = SetValList[SET_Min];
                    if (SetValChanged[SET_Sec])
                        tempTm->tm_sec = SetValList[SET_Sec];
                    RTC_SetSTm(tempTm);
                    CurMode = TimeMode;
                    break;
                }
            }
        }

        //ʱ��ģʽ�£���Ϩ��ģʽ��ʹ��BTN1�����ʱ��ģʽ
        if (VFD_IsInited() && CurMode == TimeMode && BTN_Read(BTN1))
        {
            while (BTN_Read(BTN1));


            //�����ʱ��û�������У��Ҳ���������µ�ֹͣ����ʼ����ʱ��
            if (!TimerRunning && !TimerOF)
            {
                TimerSecs = 0;
                TimerRunning = 0;
                VFD_ShowString(0, "00:00:00");
                VFD_ShowBitMap(0, IcoPause);
            }

            uint8_t forceUpdate = 1;
            char timeStr[9] = "";

            while (1)
            {
                if ((UpdateFlag && TimerRunning) || forceUpdate)
                {
                    UpdateFlag = 0;
                    forceUpdate = 0;

                    //sprintf(timeStr, "%lld:%02lld:%02lld", secs / 3600, secs / 60, secs % 60);
                    FmtTime(timeStr, TimerSecs / 3600, TimerSecs / 60 % 60, TimerSecs % 60);
                    VFD_ShowString(1, timeStr);
                    VFD_ShowBitMap(0, TimerRunning ? IcoRun : IcoPause);


                }
                if (BTN_Read(BTN2))
                {
                    while (BTN_Read(BTN2));
                    CurMode = TimerMode;
                    TimerRunning =! TimerRunning;

                    VFD_ShowBitMap(0, TimerRunning ? IcoRun : IcoPause);

                    forceUpdate = 1;
                }
                if (BTN_Read(BTN1))
                {
                    while (BTN_Read(BTN1));
                    TimerOF = 0;
                    break;
                }
            }

            CurMode = TimeMode;
        }

        //��VFD����ʱ�䰴�����ⰴ������ǿ������ʱ��
        if (!VFD_IsInited() && BTN_ReadAny())
        {
            while (BTN_ReadAny());
            ForceVFDOn = 1;
            ForceVFDOnBeg = HAL_GetTick();
            CurMode = TimeMode;
        }
        /* USER CODE END WHILE */

        /* USER CODE BEGIN 3 */
    }
    /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
    RCC_OscInitTypeDef RCC_OscInitStruct = {0};
    RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
    RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

    /** Initializes the RCC Oscillators according to the specified parameters
    * in the RCC_OscInitTypeDef structure.
    */
    RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE|RCC_OSCILLATORTYPE_LSE;
    RCC_OscInitStruct.HSEState = RCC_HSE_ON;
    RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
    RCC_OscInitStruct.LSEState = RCC_LSE_ON;
    RCC_OscInitStruct.HSIState = RCC_HSI_ON;
    RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
    RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
    RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
    if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
    {
        Error_Handler();
    }

    /** Initializes the CPU, AHB and APB buses clocks
    */
    RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                                  |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
    RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
    RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
    RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
    RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

    if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
    {
        Error_Handler();
    }
    PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_RTC;
    PeriphClkInit.RTCClockSelection = RCC_RTCCLKSOURCE_LSE;
    if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
    {
        Error_Handler();
    }
}

/* USER CODE BEGIN 4 */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
    if (htim == &htim2)
    {
        UpdateFlag = 1;
        if (TimerRunning)
        {
            //�������ֵ֮��ֱ��ͣ��
            if (TimerSecs > MAX_TIMER_VAL)
            {
                TimerRunning = 0;
                TimerOF = 1;
            }
            else
            {
                TimerSecs++;
            }
        }
    }
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
    if (huart == &huart1)
    {
        if (ch == '\n')
        {
            NewCmd = 1;
        }
        else
        {
            CmdStr[CmdLen++] = ch;
        }
        HAL_UART_Receive_IT(&huart1, &ch, 1);
    }
}

void SoftReset()
{
    __set_FAULTMASK(1);     //�ر������ж�
    NVIC_SystemReset();               //��λ
}

/*
 * @brief ��ʽ��ʱ��
 * @param sec   ��sec != -1ʱ����ʽ����
 *                  %d:%02d:%02d
 *              ��sec = -1ʱ������ʽ����
 *                  %d:%02d
 * */
void FmtTime(char* str, uint16_t h, uint8_t min, int8_t sec)
{
    uint8_t cur = 0;    //׼��д���λ�ã�д�����֮��Ӧ���Լ���Ӧ�ĳ���
    uint8_t hBits = JUDGE_BITS(h);
    uint8_t mBits = JUDGE_BITS(min);
    uint8_t sBits = JUDGE_BITS(sec);

    itoa(h, str, 10);
    cur += hBits;
    *(str + cur) = ':';
    cur++;

    if (mBits < 2)
    {
        *(str + cur) = '0';
        cur++;
    }
    itoa(min, str + cur, 10);
    cur += mBits;
    *(str + cur) = ':';
    cur++;


    if (sec != -1)
    {
        if (sBits < 2)
        {
            *(str + cur) = '0';
            cur++;
        }
        itoa(sec, str + cur, 10);
    }
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
    /* USER CODE BEGIN Error_Handler_Debug */
    /* User can add his own implementation to report the HAL error return state */
    __disable_irq();
    while (1)
    {
    }
    /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
